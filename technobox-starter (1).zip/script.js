// =============================================
//  Проект «ТехноБокс» — интернет-магазин
//
//  ТВОЯ ЗАДАЧА: оживить страницу с помощью JS.
//  HTML, CSS и data.json уже готовы — их трогать не нужно.
//  Иди по шагам из презентации и после КАЖДОГО шага
//  открывай страницу и проверяй, что всё работает.
//
//  Открывай index.html через Live Server!
// =============================================

console.log("script.js подключён! Начинай с шага 1 🚀");


// ===== ДАННЫЕ И СОСТОЯНИЕ =====
// TODO: let allProducts = []  — сюда попадут все товары из data.json
// TODO (шаг 4): const state = { query: "", sort: "none" }


// ===== ЭЛЕМЕНТЫ СТРАНИЦЫ =====
// TODO: найди через document.querySelector:
//   #catalog, #counter, #search-input, #search-btn, #sort-btn


// ===== ШАГ 1. ЗАГРУЗКА data.json =====
// TODO: async function loadProducts() { ... fetch ... await ... }


// ===== ШАГ 2. ОДИН ТОВАР -> ОДНА КАРТОЧКА =====
// TODO: function formatPrice(price)  — 7990 -> "7 990 ₽"
// TODO: function createCard(product) — посмотри шаблон карточки в index.html


// ===== ШАГ 3. РИСУЕМ СПИСОК =====
// TODO: function render(list) — очистить, нарисовать, обновить счётчик


// ===== ШАГ 4. МОЗГ: state -> список -> render =====
// TODO: function update()


// ===== ШАГ 5. ПОИСК ПО КНОПКЕ «НАЙТИ» =====
// TODO: searchBtn.addEventListener("click", ...)


// ===== ШАГ 6. СОРТИРОВКА ПО ЦЕНЕ ↑ ↓ =====
// TODO: sortBtn.addEventListener("click", ...)


// ===== ЗАПУСК =====
// TODO: loadProducts();
